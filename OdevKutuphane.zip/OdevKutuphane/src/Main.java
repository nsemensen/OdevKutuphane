
public class Main {

	public static void main(String[] args) {
		Ebook eBook=new Ebook("Öğretmenim Mori'yle Salı Buluşmaları","Mitch ALBOM", "978-975-7004-19-6", 16585,"PDF"
				);
		PrintedBook printedBook=new PrintedBook("Artık Kendin İçin","Serdar VATANSEVER","978-625-6608-22-1",195,2024);
		eBook.displayDetails();
		System.out.println("\n");
		printedBook.displayDetails();
	}

}
