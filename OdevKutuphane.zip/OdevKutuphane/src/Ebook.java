
public class Ebook extends Book {

	private int dosyaBoyutu;
	private String dosyaFormati;

	public void displayDetails() {
		System.out.println("E-Book Bilgileri \nAdı: " + this.getBaslik() + "\nYazar: " + this.getYazar()
				+ "\nISBN: " + this.getISBN() + "\nDosya Formatı: " + this.dosyaFormati + "\nDosya Boyutu: "
				+ this.dosyaBoyutu);
	}

	public Ebook(String baslik, String yazar, String iSBN, int dosyaBoyutu, String dosyaFormati) {
		super(baslik, yazar, iSBN);
		this.dosyaBoyutu = dosyaBoyutu;
		this.dosyaFormati = dosyaFormati;
	}

}
