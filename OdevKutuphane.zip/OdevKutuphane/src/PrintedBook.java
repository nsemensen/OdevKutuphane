
public class PrintedBook extends Book {

	private int sayfaSayisi;
	private int baskiYili;
	
	@Override
	public void displayDetails() {
		System.out.println("Kitap Bilgileri \nKitap Adı: " + this.getBaslik() + "\nYazar: " + this.getYazar()
		+ "\nISBN: " + this.getISBN() + "\nSayfa Sayısı: " + this.sayfaSayisi + "\nBaskı Yılı: "
		+ this.baskiYili);
	}

	public PrintedBook(String baslik, String yazar, String iSBN, int sayfaSayisi, int baskiYili) {
		super(baslik, yazar, iSBN);
		this.sayfaSayisi = sayfaSayisi;
		this.baskiYili = baskiYili;
	}

}
