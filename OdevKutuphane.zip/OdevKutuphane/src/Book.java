
public abstract class Book {

	private String baslik;
	private String yazar;
	private String ISBN;
	
	public abstract void displayDetails();

	public String getBaslik() {
		return baslik;
	}

	public void setBaslik(String baslik) {
		this.baslik = baslik;
	}

	public String getYazar() {
		return yazar;
	}

	public void setYazar(String yazar) {
		this.yazar = yazar;
	}

	public String getISBN() {
		return ISBN;
	}

	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}

	public Book(String baslik, String yazar, String iSBN) {
		this.baslik = baslik;
		this.yazar = yazar;
		ISBN = iSBN;
	}
}
